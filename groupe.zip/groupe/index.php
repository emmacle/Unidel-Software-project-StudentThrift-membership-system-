
<?php
include('includes/config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        if (empty($email) || empty($password)) {
            $error_message = "Email and password are required!";
        } else {
            $hashed_password = md5($password);

            $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$hashed_password'";
            $result = $conn->query($sql);

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();

                $_SESSION['user_id'] = $row['id'];
                $_SESSION['email'] = $row['email'];

                header("Location: dashboard.php");
                exit();
            } else {
                $error_message = "Invalid email or password!";
            }
        }
    }
}
?>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SENGROUP-3</title>
    
    <link rel="stylesheet" href="style.css" />
   

    <!-- Unicons -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />

    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
  />
  </head>

  <body>

    <header>
        <input type ="checkbox" name ="" id ="chk1">
        <div class="logo"><h1>SENGROUP_E</h1></div>
            <div class="search-box">
                <form>
                    <input type ="text" name ="search" id ="srch" placeholder="Search">
                    <button type ="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Product</a></li>
                <li><a href="#">Blog</a></li>
                <button class="button" id="form-open" >login</button>
                <li>
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                      
                        </li>
            </ul>
            <div class="menu">
                <label for="chk1">
                    <i class="fa fa-bars"></i>
                </label>
            </div>
    </header>

    <!-- Home -->
    <section class="home">
      <div class="form_container">
        <i class="uil uil-times form_close"></i>

        <?php
            if (isset($error_message)) {
            echo '<div class="alert alert-danger">' . $error_message . '</div>';
            }
        ?>
        <!-- Login From -->
        <div class="form login_form">
          <form action="" method="POST">
            <h2>Login</h2>

            <div class="input_box">
            <input type="email" class="form-control" name="email" placeholder="Email">
              <i class="uil uil-envelope-alt email"></i>
            </div>
            <div class="input_box">
            <input type="password" class="form-control" name="password" placeholder="Password">
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <div class="option_field">
              <span class="checkbox">
                <input type="checkbox" id="check" />
                <label for="check">Remember me</label>
              </span>
              <a href="#" class="forgot_pw">Forgot password?</a>
            </div>
            <button type="submit" name="login" class=" button btn btn-success btn-block">Log In</button>

            <div class="login_signup">Don't have an account? <a href="#" id="signup">Signup</a></div>
          </form>
        </div>

        <!-- Signup From -->
        <div class="form signup_form">
        <form action="signup.php" method="POST">
            <h2>Signup</h2>

            <div class="input_box">
            <input type="email" id="email" name="email" required><br><br>
              <i class="uil uil-envelope-alt email"></i>
            </div>
            <div class="input_box">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <button type="submit" class="button">Signup Now</button>

            <div class="login_signup">Already have an account? <a href="#" id="login">Login</a></div>
          </form>
        </div>
      </div>
    
    </section>

   <!-- <h1 class="sp"> SOFTWARE ENGINEERING 2023/2024 STUDENT RESULT CGPA[100LEVEL]</h1> -->

        
    <!-- table  -->

    <div class="table_bod">

    <main class="table">
        <section class="table__header">
            <h1>Software Engineering Result 2023/2024 {100LEV}</h1>
            <div class="input-group">
                <input type="search" placeholder="Search Data...">
                <img src="images/search.png" alt="">
            </div>
            <div class="export__file">
                <label for="export-file" class="export__file-btn" title="Export File"></label>
                <input type="checkbox" id="export-file">
                <div class="export__file-options">
                    <label>Export As &nbsp; &#10140;</label>
                    <label for="export-file" id="toPDF">PDF <img src="images/pdf.png" alt=""></label>
                    <label for="export-file" id="toJSON">JSON <img src="images/json.png" alt=""></label>
                    <label for="export-file" id="toCSV">CSV <img src="images/csv.png" alt=""></label>
                    <label for="export-file" id="toEXCEL">EXCEL <img src="images/excel.png" alt=""></label>
                </div>
            </div>
        </section>
        <section class="table__body">
            <table>
                <thead>
                    <tr>
                        <th> Id <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Name<span class="icon-arrow">&UpArrow;</span></th>
                        <th> Matric no. <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Gender <span class="icon-arrow">&UpArrow;</span></th>
                        <th> Remark <span class="icon-arrow">&UpArrow;</span></th>
                        <th> CGPA <span class="icon-arrow">&UpArrow;</span></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td> 1 </td>
                        <td> Imasa Emmanuel</td>
                        <td> Cmp2207865 </td>
                        <td>  Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>   5.0 </strong></td>
                    </tr>
                    <tr>
                        <td> 2 </td>
                        <td> Ruth Kadiri </td>
                        <td> Cmp2207869 </td>
                        <td> Female </td>
                        <td>
                            <p class="status cancelled"> poor</p>
                        </td>
                        <td> <strong>1.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 3</td>
                        <td> lucky Jessi </td>
                        <td> Cmp2207862 </td>
                        <td> Male</td>
                        <td>
                            <p class="status shipped"> v.good</p>
                        </td>
                        <td> <strong> 3.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 4</td>
                        <td> Evan James </td>
                        <td> Cmp2207861 </td>
                        <td> Female </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong> 4.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 5</td>
                        <td> Tejiri Tega </td>
                        <td> Cmp2207865 </td>
                        <td> Male </td>
                        <td>
                            <p class="status pending">good</p>
                        </td>
                        <td> <strong>2.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 6</td>
                        <td> Emilly Abraham </td>
                        <td> Cmp2206789 </td>
                        <td> Female </td>
                        <td>
                            <p class="status cancelled">poor</p>
                        </td>
                        <td> <strong>1.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 7</td>
                        <td> Eluebo Emmanuel </td>
                        <td> Cmp2204567 </td>
                        <td> Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>5.0</strong> </td>
                    </tr>

                    <tr>
                        <td> 8 </td>
                        <td> Fidelis kelly</td>
                        <td> Cmp2207865 </td>
                        <td>  Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>   5.0 </strong></td>
                    </tr>

                    <tr>
                        <td> 9 </td>
                        <td> ogenefejiro Isreal</td>
                        <td> Cmp2205865 </td>
                        <td>  Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>   5.0 </strong></td>
                    </tr>

                    <tr>
                        <td> 10 </td>
                        <td> Praise Wisdom </td>
                        <td> Cmp2209865 </td>
                        <td>  Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>   5.0 </strong></td>
                    </tr>
                    <tr>
                        <td> 11</td>
                        <td> Diven Demmy </td>
                        <td> Cmp2204560 </td>
                        <td> 30 Feb, 2023 </td>
                        <td>
                            <p class="status pending">good</p>
                        </td>
                        <td> <strong>2.5</strong> </td>
                    </tr>
                    <tr>
                        <td> 12</td>
                        <td> Teju Okon </td>
                        <td> Cmp2204562 </td>
                        <td> Female </td>
                        <td>
                            <p class="status cancelled">poor</p>
                        </td>
                        <td> <strong>1.5</strong> </td>
                    </tr>

                    <tr>
                        <td> 13 </td>
                        <td> Ejiformah Favor</td>
                        <td> Cmp2207865 </td>
                        <td>  Male </td>
                        <td>
                            <p class="status delivered">excellent</p>
                        </td>
                        <td> <strong>   5.0 </strong></td>
                    </tr>
                </tbody>
            </table>
        </section>
    </main>

</div>


    <!-- footer html code-->

        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col">
                        <h4>Developers</h4>
                        <ul>
                            <li><a href="#">Imasa Emmanuel</a></li>
                            <li><a href="#">Eluebo Emmanuel</a></li>
                            <li><a href="#">Praise Wisdom</a></li>
                            <li><a href="#">Fidelis kelly</a></li>
                            <li><a href="#">For sale</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                    <h4>Contributors</h4>
                        <ul>
                            <li><a href="#">Ejiformah Favor</a></li>
                            <li><a href="#">ogenefejiro Isreal</a></li>
                            <li><a href="#"> Ewharime Jefferson</a></li>
                            <li><a href="#"> for sale</a></li>
                            <li><a href="#">for sale</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>COURSE LIST</h4>
                        <ul>
                            <li><a href="#">Sen 101</a></li>
                            <li><a href="#">Sen 111</a></li>
                            <li><a href="#">Sen 121</a></li>
                            <li><a href="#">Csc 101</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>follow us</h4>
                        <div class="social-links">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                           
                        </div>
                    </div>

        
                </div>
            </div>
       </footer>

    <script src="script.js"></script>
  </body>
</html>
