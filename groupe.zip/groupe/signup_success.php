<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Successful</title>
    <meta http-equiv="refresh" content="5;url=index.php" />
</head>
<body>
    <h2>Signup Successful</h2>
    <p>Your account has been created successfully. You will be redirected to the login page in 5 seconds.</p>
    <p>If you are not redirected automatically, <a href="index.php">click here</a>.</p>
</body>
</html>
